import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basics',
  templateUrl: './basics.component.html',
  styleUrls: ['./basics.component.css']
})
export class BasicsComponent implements OnInit {

  constructor() { }
  myname = 'Ezhil';
  userName = 'EZHILVENDHAN';
  btnFlag = true;
  ngOnInit(): void{
    setTimeout(()=>{
      this.btnFlag = false;
    }, 2000)
  }
  onclick()
  {
    console.log('onclick Function Invoked.');
  }
}
