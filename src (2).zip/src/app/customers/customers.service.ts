import { Injectable } from '@angular/core';
import { Customer } from './customers.component';
@Injectable({
  providedIn: 'root'
})
export class CustomersService {
    customers: Customer[] = [
      {id: 1501, name: 'Ram', email: 'abc@gmail.com'},
      {id: 1502, name: 'Ravi', email: 'def@gmail.com'},
      {id: 1503, name: 'Ramesh', email: 'ghi@gmail.com'},
    ];
  
      constructor() { }
      getCustomers() {
        return this.customers;
      }
      getCustomer(id: number) {
        const customer = this.customers.find(
          (element) => {
           return element.id === id;
          }
        );
        return customer;
      }
      updateCustomer(id: number, customerInfo: {name: string, email: string}) {
        const customer = this.getCustomer(id);
        if(customer) {
          customer.name = customerInfo.name;
          customer.email = customerInfo.email;
        }
      }
    }
    