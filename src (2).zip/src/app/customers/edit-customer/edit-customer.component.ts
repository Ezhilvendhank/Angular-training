import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { Customer } from '../customers.component';
import { CustomersService } from '../customers.service';

@Component({
  selector: 'app-edit-customer',
  templateUrl: './edit-customer.component.html',
  styleUrls: ['./edit-customer.component.css']
})
export class EditCustomerComponent implements OnInit {
  customer: Customer = {};
  customerName!: string;
  customerStatus!: string;
  customerId!: number;
  customerEmail!: string;
    constructor(public service: CustomersService,
                 public aRoute: ActivatedRoute,
                 public router: Router) { }
  
    ngOnInit(): void {
      this.customerId = +this.aRoute.snapshot.params['id'];
      this.customer = this.service.getCustomer(this.customerId)!;
      //this.aRoute.params.subscribe((params:Params)=>{
      //this.customer = this.service.getCustomer(params['id'])!;
      //});
      this.customerName = this.customer.name!;
      this.customerEmail= this.customer.email!;
      
    }
    updateCustomer(){
      this.service.updateCustomer(this.customer.id!, {name:this.customerName,email:this.customerEmail});
      this.router.navigate(['/customers', this.customerId]);
    }
  }