import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { Customer } from '../customers.component';
import { CustomersService } from '../customers.service';
@Component({
  selector: 'app-display-customer',
  templateUrl: './display-customer.component.html',
  styleUrls: ['./display-customer.component.css']
})
export class DisplayCustomerComponent implements OnInit {
  customer!: Customer;
  customerId!: number;
    constructor(public service: CustomersService, 
                  public router: Router,
                  public aRoute: ActivatedRoute) { }
  
    ngOnInit(): void {
      this.customerId = +this.aRoute.snapshot.params['id'];
      // console.log('Received Server Id:' +serverId);
      // + means convert string to number
      this.aRoute.params.subscribe(
        (param: Params)=>{
          this.customer = this.service.getCustomer(+param['id'])!;
        },
      );
      
    }
  onEditCustomer(){
  //this.router.navigate(['/customers', this.customerId, 'edit']);
  this.router.navigate(['edit'], {relativeTo: this.aRoute});
  }
  }
  