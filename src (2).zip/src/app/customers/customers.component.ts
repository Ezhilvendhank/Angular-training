import { Component, OnInit } from '@angular/core';
import { CustomersService } from './customers.service';

export interface Customer {
  id?: number;
  name?: string;
  email?: string;
}
@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomersComponent implements OnInit {
customers: Customer[] = [];
  constructor(public service: CustomersService) { }

  ngOnInit(): void {
    this.customers = this.service.getCustomers();
  }

}
