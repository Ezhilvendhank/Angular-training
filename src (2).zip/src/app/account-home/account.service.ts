import { Injectable } from '@angular/core';
import { LoggingService } from '../logging.service';

@Injectable({
  providedIn: 'root'
})
export class AccountService {
  private accounts = [
    {name: 'Fullstack Account', status: 'active'}
  ]
  
  constructor(public logService: LoggingService) { }
  getAccounts() {
    return this.accounts;
  }
  addAccount(accname: string, accstatus: string){
    this.accounts.push({
      name: accname,
      status: accstatus
    });
    this.logService.logStatusChange(accstatus);
  }
  updateStatus(id: number, accstatus: string){
    this.accounts[id].status = accstatus;
  }
}
