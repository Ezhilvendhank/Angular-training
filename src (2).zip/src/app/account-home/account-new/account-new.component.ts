import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { AccountService } from '../account.service';

@Component({
  selector: 'app-account-new',
  templateUrl: './account-new.component.html',
  styleUrls: ['./account-new.component.css']
})
export class AccountNewComponent implements OnInit {
//@Output() createAccount = new EventEmitter<{name: string, status: string}>();
  constructor(public service: AccountService) { }

  ngOnInit(): void {
  }
onCreateAccount(aName: string, aStatus: string){
  this.service.addAccount(aName, aStatus);
  // this.createAccount.emit({
  // name: aName,
  // status: aStatus
  // });
  // console.log('A account status changed, new status: '+aStatus);
}
}
