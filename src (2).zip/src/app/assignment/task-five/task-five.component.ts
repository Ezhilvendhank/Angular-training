import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-task-five',
  templateUrl: './task-five.component.html',
  styleUrls: ['./task-five.component.css']
})
export class TaskFiveComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
