import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CounterService {
  activeToInactiveCount = 0;
  inActiveToActiveCount = 0;
  constructor() { }
  incrementActiveToInactive() {
     this.activeToInactiveCount++;
     console.log('Active to Inactive: '+this.activeToInactiveCount)
  }
  incrementInactiveToActive(){
      this.inActiveToActiveCount++;
      console.log('Inactive to Active: '+this.inActiveToActiveCount)
  }
}
