import { Injectable } from '@angular/core';
import { CounterService } from './counter.service';

@Injectable({
  providedIn: 'root'
})
export class UsersService {
  [x: string]: any;
  activeUsers = ['Max', 'Chad', 'Kannan'];
  inactiveUsers = ['Antony', 'Ivan'];
  onSetToActive: any;
  constructor(public cService: CounterService) { }
  setToActive(id: number){
  this.activeUsers.push(this.inactiveUsers[id]);
  this.inactiveUsers.splice(id, 1);
  this.cService.incrementInactiveToActive();

  }
  setToInactive(id: number){
  this.inactiveUsers.push(this.activeUsers[id]);
  this.activeUsers.splice(id, 1);
  this.cService.incrementActiveToInactive();
  }
}
