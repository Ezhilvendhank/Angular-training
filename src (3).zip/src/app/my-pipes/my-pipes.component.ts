import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-pipes',
  templateUrl: './my-pipes.component.html',
  styleUrls: ['./my-pipes.component.css']
})
export class MyPipesComponent implements OnInit {
 filterText = '';
  servers = [
    {instanceType: 'medium', name: 'Production Server', status: 'stable', started: new Date()},
    {instanceType: 'large', name: 'User Database', status: 'offline', started: new Date()},
    {instanceType: 'small', name: 'Development Server', status: 'critical', started: new Date()},
    {instanceType: 'small', name: 'Testing Server', status: 'stable', started: new Date()},
  ];
  constructor() { }

  ngOnInit(): void {
  }
getStatusClasses(status: string){
return {
  'list-group-item-success': status === 'stable',
  'list-group-item-warning': status ==='offline',
  'list-group-item-danger': status === 'critical',
}
}
}
