import { Component, OnDestroy, OnInit } from '@angular/core';
import { filter, interval, map, Observable, Observer, Subscription } from 'rxjs';

@Component({
  selector: 'app-rxjs-home',
  templateUrl: './rxjs-home.component.html',
  styleUrls: ['./rxjs-home.component.css']
})
export class RxjsHomeComponent implements OnInit, OnDestroy{

  private mySubscription!: Subscription;

  constructor() { }

  ngOnInit(): void {
    this.mySubscription = interval(1000).subscribe(count => {
      console.log(count);
    });
    console.log('create custom interval using Observable')
    const customInterval = new Observable((observer: Observer<any>)=>{
      let count = 0;
      setInterval(()=>{
        observer.next(count);
        if(count === 15) {
          observer.complete();
        }
        count++;
      }, 1000);
      });
      this.mySubscription = customInterval.pipe(
        filter(data => {
          return data>5;
        }), map((data: number) => {
          return 'Convert Even:: '+(data+1)
        })
        ).subscribe(
            (response) => {
              console.log(response);
            },
            (error) => {
              console.log('Error: '+error.message);
            },
            () => {
              console.log('Completed!');
            }
        );
          }
  //   this.mySubscription = customInterval.subscribe(
  //     (data) => {
  //       console.log(data);
  //     },
  //     (error) => {

  //     },
  //     () => {
  //       console.log('Subscription was completed!');
  //     }
  //   );
   

ngOnDestroy():  void {
  this.mySubscription.unsubscribe()
}
} 
