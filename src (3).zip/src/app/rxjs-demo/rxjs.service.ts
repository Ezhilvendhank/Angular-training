import { EventEmitter, Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RxjsService {
  activatedEmitter = new EventEmitter<boolean>();
  deActivatedSubject = new Subject<boolean>();
  constructor() { }
}
