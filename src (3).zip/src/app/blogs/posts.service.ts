import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs';
import { Post } from './post.module';

@Injectable({
  providedIn: 'root'
})
export class PostsService {
  get // error =>console.log(error)
    (arg0: string) {
      throw new Error('Method not implemented.');
  }

  constructor(public http: HttpClient) { }
   url: string='https://newfsd-4c653-default-rtdb.asia-southeast1.firebasedatabase.app/ezhi13726.json';
  createAndStorePost(formData: Post){
    this.http.post(this.url,postForm).subscribe(
      // response=> console.log(response),
      // error =>console.log(error)
    )
  } 
  fetchPost(){
   return this.http.get<{[key: string]: Post}>(this.url,{responseType: 'json'}).pipe
   (map((responseData)=>{
      const postArray: Post[] = [];
    for(const key in responseData){
    if(responseData.hasOwnProperty(key)){
      postArray.push({...responseData[key], id: key});
    }}
    //console.log(postArray);
return postArray;
    })
    );
  }
  deletePosts() {
    this.http.delete(this.url);
  }
}
function postForm(url: string, postForm: any) {
  throw new Error('Function not implemented.');
}

