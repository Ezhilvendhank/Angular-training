import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FlexLayoutModule } from '@angular/flex-layout';
import { AppComponent } from './app.component';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RxjsDemoComponent } from './rxjs-demo/rxjs-demo.component';
import { RxjsHomeComponent } from './rxjs-demo/rxjs-home/rxjs-home.component';
import { RxjsUserComponent } from './rxjs-demo/rxjs-user/rxjs-user.component';
import { RouterModule, Routes } from '@angular/router';
import { MaterialModule } from './material/material.module';
import { TdFormsComponent } from './td-forms/td-forms.component';
import { LoginComponent } from './td-forms/auth/login/login.component';
import { SignupComponent } from './td-forms/auth/signup/signup.component';
import { TrainingComponent } from './td-forms/training/training.component';
import { CurrentTrainingComponent } from './td-forms/training/current-training/current-training.component';
import { NewTrainingComponent } from './td-forms/training/new-training/new-training.component';
import { PastTrainingComponent } from './td-forms/training/past-training/past-training.component';
import { WelcomeComponent } from './td-forms/welcome/welcome.component';
import { AppRoutingModule } from './app-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MyPipesComponent } from './my-pipes/my-pipes.component';
import { ShortenPipe } from './my-pipes/shorten.pipe';
import { BlogsComponent } from './blogs/blogs.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ReactiveFormsComponent } from './reactive-forms/reactive-forms.component';
import { LoggingInterceptorService } from './blogs/logging-interceptor.service';
import { MyVoteComponent } from './UnitTesting/o8-vote/my-vote.component';
import { UserComponent } from './IntegrationTesting/user/user.component';
import { UserDetailsComponent } from './IntegrationTesting/user-details/user-details.component';
import { IntegrationComponent } from './IntegrationTesting/integration/integration.component';
import { IntegrationRoutingModule } from './IntegrationTesting/integration/integration-routing.module';
import { HomeComponent } from './IntegrationTesting/home/home.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { HighlightDirective } from './highlight.directive';
import { HostComponent } from './host.component';
//import { AuthInterceptorService } from './blogs/auth-interceptor.service';

const routes: Routes = [
  {path: 'home', component: HomeComponent},
  {path: 'rxjs', component: RxjsDemoComponent, children: [
     {path: 'home', component: RxjsHomeComponent},
     {path: 'user/:id', component: RxjsUserComponent},
     {path: 'pipes', component:MyPipesComponent},
     {path: 'blogs', component:BlogsComponent},
]},
{path: 'td-forms', component: TdFormsComponent, children: [
  {path: 'welcome', component: WelcomeComponent},
  {path: 'signup', component: SignupComponent},
  {path: 'login', component: LoginComponent},
  {path: 'training', component: TrainingComponent, children: [
    {path: 'current', component: CurrentTrainingComponent},
    {path: 'past', component: PastTrainingComponent},
    {path: 'new', component: NewTrainingComponent}
  
  ]}
]},

{path: 'reactive-forms', component: ReactiveFormsComponent},
{path: 'my-Voting', component: MyVoteComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    RxjsDemoComponent,
    RxjsHomeComponent,
    RxjsUserComponent,
    TdFormsComponent,
    LoginComponent,
    SignupComponent,
    TrainingComponent,
    CurrentTrainingComponent,
    NewTrainingComponent,
    PastTrainingComponent,
    WelcomeComponent,
    MyPipesComponent,
    ShortenPipe,
    BlogsComponent,
    ReactiveFormsComponent,
    MyVoteComponent,
    UserComponent,
    UserDetailsComponent,
    IntegrationComponent,
    HomeComponent,
    PageNotFoundComponent,
    HighlightDirective,
    HostComponent
  ],
  imports: [
    BrowserModule,
    NoopAnimationsModule,
    AppRoutingModule,
    FormsModule,
    RouterModule.forRoot(routes),
    MaterialModule,
    FlexLayoutModule,
    HttpClientModule,
    ReactiveFormsModule,
    IntegrationRoutingModule
  ],
  providers: [
    {provide: HTTP_INTERCEPTORS, useClass: LoggingInterceptorService, multi: true},
    //{provide: HTTP_INTERCEPTORS, useClass: AuthInterceptorService, multi: true}
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
