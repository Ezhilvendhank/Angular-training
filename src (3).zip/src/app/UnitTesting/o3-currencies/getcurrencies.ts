export const getcurrencies = () => {
    return ['INR', 'USD', 'EUR'];
}