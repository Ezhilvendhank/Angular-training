
import { getcurrencies } from "./getcurrencies"

describe('getcurrencies', () => {
 it('should return the supported currencies',()=>{
     const result = getcurrencies();
     expect(result).toContain('INR');
     expect(result).toContain('USD');
     expect(result).toContain('EUR');
 })
})