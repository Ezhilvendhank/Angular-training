import { FormBuilder } from "@angular/forms";
import { TodoFormsComponent } from "./todo-forms.component"

describe('TodoFormsComponent', ()=>{
    let todoForms: TodoFormsComponent;
    beforeEach(()=>{
        todoForms = new TodoFormsComponent(new FormBuilder());
    });
    it('should be create TodoForms Instance', ()=>{
        expect(todoForms).toBeTruthy();
    });
    it('should create a form with two form controls.', ()=>{
      expect(todoForms.form?.contains('userName')).toBeTruthy();
      expect(todoForms.form?.contains('email')).toBeTruthy();
    });
    it('should make the username-1 control required.', ()=>{
        const control = todoForms.form?.get('userName');
        control?.setValue('ezhil');
        expect(control?.valid).toBeTruthy();
    });
    it('should make the username-2 control required.', ()=>{
        const control = todoForms.form?.get('userName');
        control?.setValue('');
        expect(control?.valid).toBeFalsy();
    });
    it('should make the email control required.', ()=>{
        const control = todoForms.form?.get('email');
        control?.setValue('ezhilvendhan1111@gmail.com');
        expect(control?.valid).toBeTruthy();
    });
})