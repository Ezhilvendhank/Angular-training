export const compute = (
    (num: number)=>{
    if(num < 1) {
        return 0;
    }
    return num + 5;
});