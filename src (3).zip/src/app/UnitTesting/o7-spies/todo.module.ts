export interface Todo {
    id?: number;
    activity?: string;
    targetDate?: string;
    status?: string;
}