import { HttpClient, HttpHandler } from "@angular/common/http";
import { expressionType } from "@angular/compiler/src/output/output_ast";

import { EMPTY, from, of, throwError } from "rxjs";
import { TodoComponent } from "./todo.component"
import { Todo } from "./todo.module";
import { TodoService } from "./todo.service";


describe('TodoComponent', ()=>{
    let component: TodoComponent;
    let service: TodoService;
    beforeEach(()=>{
        const spy = jasmine.createSpyObj('HttpClient', {post: of({}), get: of({}), delete: of({}) });
        service = new TodoService(spy);
        component = new TodoComponent(service);
    });
    it('should create the Todo instance.', ()=>{
    expect(component).toBeTruthy();
    });
     it('should call the server to save changes when new todo items is added.', ()=>{
         const todos: Todo[] = [
             {id: 101, activity: 'Learn Angular', targetDate: '30-Dec-2021', status: 'In progress'},
             {id: 102, activity: 'Learn Angular', targetDate: '30-Dec-2021', status: 'In progress'},
             {id: 103, activity: 'Learn Angular', targetDate: '30-Dec-2021', status: 'In progress'}
         ];
         spyOn(service, 'getTodos').and.callFake(()=>{
             return from([todos]);
         });
         component.ngOnInit();
         expect(component.todos.length).toBe(0);
     });
     it('shoud call the server to save changes when a new todo items is added',()=>{
         const spy = spyOn(service, 'add').and.callFake(()=>{
             return EMPTY;
         });
         component.onAddTodo();
         expect(spy).toHaveBeenCalled();

        })
     it('should add the new todo returned from the server.', ()=>{
         const todo: Todo = {id: 104, activity: 'Learn GCP certification', targetDate: '30-Dec-2021', status: 'In progress'};
        //  spyOn(service, 'add').and.callFake(()=>{
        //      return from([todo]);
        //  });
        spyOn(service, 'add').and.returnValue(from([todo]));
         component.onAddTodo();
        // expect(component.todos.indexOf(todo)).toBeGreaterThan(-1);
        expect(component.todos[0].id).toBe(104);
     }) 
     it('should set the message property if server returned an error', ()=> {
         const errorMessage = 'Error from todo server.';
         spyOn(service, 'add').and.returnValue(throwError(errorMessage));
         component.onAddTodo();
         expect(component.message).toBe(errorMessage);
     })
     it('should call the server to delete a todo item if the user confirm', ()=>{
         const id = 102;
         spyOn(window, 'confirm').and.returnValue(true);
         const spy = spyOn(service, 'deleteTodo').and.returnValue(EMPTY);
         component.onDeleteTodo(id);
         expect(spy).toHaveBeenCalledWith(102);
     })
     it('should NOT call the server to delete a todo item if the user not confirm', ()=>{
     const id = 105;
     spyOn(window, 'confirm').and.returnValue(false);
     const spy = spyOn(service, 'deleteTodo').and.returnValue(EMPTY);
     component.onDeleteTodo(id);
     expect(spy).not.toHaveBeenCalled();
     })
})