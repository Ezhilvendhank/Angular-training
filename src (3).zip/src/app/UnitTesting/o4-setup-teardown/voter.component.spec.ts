import { VoterComponent } from "./voter.component"

describe('VoterComponent', ()=>{
    let component: VoterComponent;
    beforeEach(()=>{
        component = new VoterComponent();
    });
    it('should be create the Instance.', ()=>{
          expect(component).toBeTruthy();
    }),
    it('should increment totalVotes for upVoted.', ()=>{
           component.upVote();
           expect(component.totalVotes).toBe(1);
    });
    it('should decrement totalVotes for downVoted.', ()=>{
        component.downVote();
        expect(component.totalVotes).toBe(-1);
    });
})