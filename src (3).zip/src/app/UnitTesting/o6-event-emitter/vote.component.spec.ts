import { VoteComponent } from "./vote.component"

describe('VoteComponent', ()=>{
    let component: VoteComponent;
    beforeEach(()=>{
        component= new VoteComponent();
    });
    it('should raise voteChanged event when upvoted', ()=>{
        let totalVotes = 0;
        component.voteChanged.subscribe(tVotes => {
            totalVotes = tVotes;
        });
        component.upVote();
        //expect(totalVotes).not.toBe(0);
        expect(totalVotes).toBe(1);
    })
})