
export const greet = (name :string)=>{
    return 'Welcome ' +name+'!.';

}
