
import { greet } from "./greet";



describe('greet', ()=>{
    it('should display with Welcome and !. string',()=>{
        expect(greet('Max')).toBe('Welcome Max!.')
    })
    it('should include the name in the message',()=>{
        expect(greet('ezhil')).toContain('ezhil');


    });
})
